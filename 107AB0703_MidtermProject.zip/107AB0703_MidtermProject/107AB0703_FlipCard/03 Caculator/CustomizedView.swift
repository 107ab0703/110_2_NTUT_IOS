//
//  CustomizedView.swift
//  MainProject
//
//  Created by 呂晨汝 on 2022/3/11.
//
// https://ithelp.ithome.com.tw/articles/10217669
// https://www.appcoda.com.tw/calayer-introduction/

import UIKit

@IBDesignable class CustomizedView: UIView {
    
    /// 陰影偏移(5,5:表示往下往右偏移五點)
    @IBInspectable var shadowOffset: CGSize = .zero {
        didSet {
            layer.shadowOffset = shadowOffset
        }
    }
    
    /// 陰影透明度
    @IBInspectable var shadowOpacity: Float = 0.0 {
        didSet {
            layer.shadowOpacity = shadowOpacity
        }
    }
    
    /// 陰影範圍(數值越高則越模糊且分散)
    @IBInspectable var shadowRadius: CGFloat = 0.0 {
        didSet {
            layer.shadowRadius = shadowRadius
        }
    }
    
    /// 陰影顏色
    @IBInspectable var shadowColor: UIColor = UIColor.black {
        didSet {
            layer.shadowColor = shadowColor.cgColor
        }
    }
    
    /// 圓角
    @IBInspectable var cornerRadius: CGFloat = 0.0 {
        didSet {
            layer.cornerRadius = cornerRadius
        }
    }
    
    /// 變成圓型
    @IBInspectable var circleRadius: Bool = true {
        didSet {
            layer.cornerRadius = frame.height / 2
        }
    }
    
    /// 邊框顏色
    @IBInspectable var borderColor: UIColor = .black {
        didSet {
            layer.borderColor = borderColor.cgColor
        }
    }
    
    /// 邊框寬度
    @IBInspectable var borderWidth: CGFloat = 0.0 {
        didSet {
            layer.borderWidth = borderWidth
        }
    }
    
}
