//
//  ViewController.swift
//  03 Caculator
//
//  Created by 汝 on 2022/3/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var processLabel: UILabel!
    @IBOutlet weak var outputLabel: UILabel!
    @IBOutlet weak var clearBtn: UIButton!
    @IBOutlet weak var addView: UIView!
    @IBOutlet weak var subtractView: UIView!
    @IBOutlet weak var mutiplyView: UIView!
    @IBOutlet weak var devideView: UIView!
    @IBOutlet weak var addBtn: UIButton!
    @IBOutlet weak var subtractBtn: UIButton!
    @IBOutlet weak var mutiply: UIButton!
    @IBOutlet weak var devideBtn: UIButton!
    
    var preNumStr: String = ""
    var answer: Double = 0
    lazy var opr = CaculateModel().oprator
    var outputEnd = false
    var processText: String = "" {
        didSet {
            clearBtn.setTitle("C", for: .normal)
            processLabel.text = processText
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        processLabel.text = ""
        outputLabel.text = "0"
    }
    
    //點選數字＆小數點
    @IBAction func numberTapped(_ sender: UIButton) {
        processText += sender.currentTitle!
        preNumStr += sender.currentTitle!
        OprHighlight(on: false)
    }
    
    @IBAction func operatorTouchUp(_ sender: UIButton) {
        validateLable() // 去掉多餘的0
        outputToLabel() // for if outputEnd
        processText += sender.currentTitle!
        calculateNum()
        outputToLabel() // for 一般計算後輸出
        opr = CaculateModel.opr(rawValue: sender.currentTitle!)
        OprHighlight()
    }
    
    @IBAction func float(_ sender: UIButton) {
        //小數點只能按一次
        if !preNumStr.contains("."), !preNumStr.isEmpty {
            processText += sender.currentTitle!
            preNumStr += sender.currentTitle!
        }
    }
    
    @IBAction func positiveOrNegative(_ sender: UIButton) {
        if var _preNum = Double(preNumStr), _preNum != 0 {
            _preNum = _preNum > 0 ? -_preNum : abs(_preNum)
            processText = processText.getPrefix(toLast: preNumStr.count) + " \(fixNumber(_preNum)) "
            preNumStr = String(_preNum)
        } else if outputEnd {
            answer = answer > 0 ? -answer : abs(answer)
            outputToLabel(end: false)
        }
    }
    
    @IBAction func percentage(_ sender: UIButton) {
        if var _preNum = Double(preNumStr), _preNum != 0 {
            _preNum = _preNum / 100
            processText = processText.getPrefix(toLast: preNumStr.count) + fixNumber(_preNum)
            preNumStr = String(_preNum)
        } else if outputEnd {
            answer = answer / 100
            outputToLabel(end: false)
        }
    }
    
    @IBAction func outputAns(_ sender: UIButton) {
        validateLable()
        processText += sender.currentTitle!
        calculateNum()
        outputLabel.text = fixNumber(answer, end: true)
        outputEnd = true
    }
    
    @IBAction func toZero(_ sender: UIButton) {
        if sender.currentTitle == "AC" || outputEnd {
            clear()
            return
        }
        // 最後一個輸入為數字時: 清除上一個數字 (保留運算符號)
        if !preNumStr.isEmpty {
            processText = processText.getPrefix(toLast: preNumStr.count)
            preNumStr.removeAll()
            //前一個運算符號會被highlight, C 變成AC
            OprHighlight()
        }
        // 最後一個輸入為符號時: 不清除 (保留運算符號)
        clearBtn.setTitle("AC", for: .normal)
    }
    
    /// 顯示答案
    /// 5+2=7 -> 按運算符號（實際上answer=7.0 所以要去小數）
    private func outputToLabel(end: Bool = true) {
        outputLabel.text = fixNumber(answer)
        //按等於後繼續運算
        if outputEnd {
            processText = fixNumber(answer)
            outputEnd = end ? false : true
        }
    }
    
    private func calculateNum() {
        //目前動作：40+20-20
        //實際計算：40+20
        //opr：.subtract
        print("Last Num: \(preNumStr)")
        print("answer: \(answer)")
        guard let preNum = Double(preNumStr) else { return }
        switch opr {
        case .add:
            answer += preNum
        case .subtract:
            answer -= preNum
        case .mutiply:
            answer *= preNum
        case .devide:
            answer /= preNum
            // 除數為0不能除，顯示0
            answer = answer == .infinity ? 0 : answer
        default:
            answer = preNum
        }
        print(opr ?? "opr = nil")
        print("output: \(answer)")
        preNumStr.removeAll()
    }
    
    /// 去掉多餘的0(前面與後面)
    private func validateLable() {
        if outputEnd {
            return //等於後繼續運算不用檢核
        }
        // 一律轉成double 再重新顯示
        if let correctNum = Double(preNumStr) {
            let removeStr = processText.getPrefix(toLast: preNumStr.count) //去除錯誤的字串
            processText = removeStr + fixNumber(correctNum)
        } else {
            // 直接按下運算符號預設以0為初始數字
            preNumStr = "0"
            processText = "0"
        }
    }
    
    private func clear() {
        processText.removeAll()
        outputLabel.text = "0"
        preNumStr.removeAll()
        answer = 0
        outputEnd = false
        opr = nil
        OprHighlight(on: false)
    }
    
    /// 轉換double形態之整數，並回傳字串(15.0 -> 15)
    private func fixNumber(_ double: Double, end: Bool = false) -> String {
        let isInteger = String(double).last == "0"
        //按等於才調整小數位數
        if end {
            if isInteger {
                return String(format: "%.0f", double)
            } else {
                //設定最多取小數後八位
                let dotIndex = String(double).firstIndex(of: ".")
                let digits: Int = String(double).distance(from: dotIndex!, to: String(double).endIndex)
                let num = digits > 8 ? String(format: "%.8f", double) : String(double)
                return fixNumber(Double(num)!) //轉會後會= 1.250000，所以在校正一次 -> 1.25
            }
        } else {
            return isInteger ? String(format: "%.0f", double) : String(double)
        }
    }
    
    //運算符號highlight
    private func OprHighlight(on: Bool = true) {
        //先把上一個取消
        addView.unhighlight()
        subtractView.unhighlight()
        mutiplyView.unhighlight()
        devideView.unhighlight()
        switch opr {
        case .add:
            on ? addView.highlight() : addView.unhighlight()
        case .subtract:
            on ? subtractView.highlight() : subtractView.unhighlight()
        case .mutiply:
            on ? mutiplyView.highlight() : mutiplyView.unhighlight()
        case .devide:
            on ? devideView.highlight() : devideView.unhighlight()
        default:
            return
        }
    }
    
}

extension UIView {
    
    func highlight() {
        self.backgroundColor = UIColor.lightGray
    }
    func unhighlight() {
        self.backgroundColor = UIColor.white
    }
}

extension String {
    //https://badgameshow.com/steven/swift/swift-字串擷取-文字擷取/
    func formateInt(to: Int) {
        var str = self
        let endindex = self.index(self.startIndex, offsetBy: to)
        str.removeSubrange(startIndex...endindex)
    }

    /// 取得去除後面字數之字串
    func getPrefix(toLast: Int) -> String {
        let endindex = self.index(self.endIndex, offsetBy: -toLast)
        return String(self.prefix(upTo: endindex))
    }
}
