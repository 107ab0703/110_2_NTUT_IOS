//
//  CaculateModel.swift
//  03 Caculator
//
//  Created by 汝 on 2022/4/26.
//

import Foundation

class CaculateModel {
    
    enum opr: String {
        case add = "+"
        case subtract = "-"
        case mutiply = "×"
        case devide = "÷"
        case percentage
    }
    
    private var mOpr: opr?
    var oprator: opr? {
        get {
            return mOpr
        }
        set {
            mOpr = newValue
        }
    }
    
}
